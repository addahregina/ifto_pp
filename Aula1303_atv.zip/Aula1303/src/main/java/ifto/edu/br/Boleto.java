package ifto.edu.br;

public class Boleto {
}
