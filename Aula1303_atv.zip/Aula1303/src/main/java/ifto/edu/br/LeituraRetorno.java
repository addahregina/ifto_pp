package ifto.edu.br;

public class LeituraRetorno {
}
