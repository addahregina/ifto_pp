package ifto.edu.br;

import java.net.URI;
import java.util.List;

public class ProcessarBoleto{
    //leituraRetorno: Function<String, List<Boleto>>

    public void processar(URI caminhoArquivo){
        List<Boleto> boletos = leituraRetorno.apply(caminhoArquivo);
        for (Boleto boleto : boletos) {
            System.out.println(boleto);
        }
    }
}
