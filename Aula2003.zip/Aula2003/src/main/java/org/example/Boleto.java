package org.example;

public class Boleto implements Pagamento{
    public boolean pagar(){
        @Override
        System.out.println("Gera Boleto");
        return true;
    }
}
