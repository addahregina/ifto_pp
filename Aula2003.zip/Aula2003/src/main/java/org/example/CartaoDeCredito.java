package org.example;

public class CartaoDeCredito implements Pagamento{

}
