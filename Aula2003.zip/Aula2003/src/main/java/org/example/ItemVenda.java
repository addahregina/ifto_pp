package org.example;

public class ItemVenda {
    Venda venda;
    Produto produto;
    private  item quantidade;

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public item getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(item quantidade) {
        this.quantidade = quantidade;
    }
}
