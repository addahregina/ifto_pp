package org.example;

public interface Pagamento {
    void pagar();
}
