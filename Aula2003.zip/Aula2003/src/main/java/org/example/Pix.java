package org.example;

public class Pix implements Pagamento{
    public boolean pagar(){
        @Override
                System.out.println("Gera QRCode PIX");
        return true;
    }
}
