package org.example;

import java.util.List;

//alt+enter Implement Abstract Class
public abstract  class Venda {
    Cliente cliente;

    public Pagamento getPagamento() {
        return pagamento;
    }

    public void setPagamento(Pagamento pagamento) {
        this.pagamento = pagamento;
    }

    Pagamento pagamento;

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<itemVenda> getItens() {
        return itens;
    }

    public void setItens(List<itemVenda> itens) {
        this.itens = itens;
    }

    private List<itemVenda> itens;

    public void finalizar(){
        /*    reservar produto no estoque (para impedir que seja vendido para outro usuário);
        */

        reservarProduto();

        /*realizar pagamento;
        * muda para cada tipo
        */
        realizarPagamento();

        /*
        emitir nota fiscal;
        lojafisica, imprime nota; online = gera pdf
         */
        emitirNotaFiscal();

        /*Imprimir nota fiscal
        * Abstrato */
        imprimirNotaFiscal();

        /*encaminhar solicitação para próximo setor responsável.
        * loja virtual: setor separação de pedido; fisica: envia para o caixa /abstrato
        */
        encaminharPedidoProximoSetor();

    }

    private void realizarPagamento() {
        pagamento.pagar();
    }

    protected abstract void encaminharPedidoProximoSetor();

    protected abstract void imprimirNotaFiscal();


    private void emitirNotaFiscal() {
        System.out.println("Emitindo NF");
    }

    private void reservarProduto() {
        //itens.for ->gera o for
        for (itemVenda item : itens) {
           item.getProduto().addEstoque(item.getQuantidade());
        }
    }
}
