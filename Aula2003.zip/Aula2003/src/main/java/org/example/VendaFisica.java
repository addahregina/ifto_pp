package org.example;

public class VendaFisica extends Venda {
    @Override
    protected void encaminharPedidoProximoSetor() {
        System.out.println("Encaminhando para o caixa");
    }

    @Override
    protected void imprimirNotaFiscal() {
        System.out.println("Mandando para a impressora");
    }

    @Override
    protected void realizarPagamento() {
        //considera o pagamento separado do sistema; confirmação manual.
        System.out.println("Aguardando confirmação de pagamento");
    }
}
