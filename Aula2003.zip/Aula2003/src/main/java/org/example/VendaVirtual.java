package org.example;

public class VendaVirtual extends Venda {
    @Override
    protected void encaminharPedidoProximoSetor() {
        System.out.println("Encaminhar para o sertor de segurança para verificar pedido");
    }

    @Override
    protected void imprimirNotaFiscal() {
        System.out.println("Não há impressão. Gerar PDF");

    }

    @Override
    protected void realizarPagamento() {
        System.out.println("Encaminhar dados para serviço de pagamento ");
    }
}
