package br.edu.ifto.templatemethod;

public interface LeituraRetorno {
        String Boleto = processarLinhaArquivo(Boleto boleto);

    protected abstract Boleto processarLinhaArquivo(String[] vetor){
        

        return null;
    }

}
