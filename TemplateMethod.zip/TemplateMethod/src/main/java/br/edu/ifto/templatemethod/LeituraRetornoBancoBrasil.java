package br.edu.ifto.templatemethod;

public class LeituraRetornoBancoBrasil implements LeituraRetorno{
    //não ha metodo protegido em interface

}
