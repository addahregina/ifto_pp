package br.edu.ifto.templatemethod;

public class LeituraRetornoBradesco implements LeituraRetorno {
}
