package br.edu.ifto.templatemethod;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class LeituraRetornoBancoBrasil extends ProcessarBoletos{

    @Override
    public Boleto processarLinhaArquivo(String[] vetor){
        var boleto = new Boleto();
        boleto.setId(Integer.parseInt(vetor[0]));
        boleto.setCodBanco(vetor[1]);
        var format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        boleto.setDataVencimento(LocalDate.parse(vetor[2], format));
        var data = LocalDate.parse(vetor[3], format);
        boleto.setDataPagamento(data.atTime(0, 0));
        return boleto;
    }

}
