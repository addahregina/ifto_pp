package br.edu.ifto.templatemethod;

public class Principal {
    public static void main(String[] args){
        var leituraRetorno = new LeituraRetornoBancoBrasil();
        leituraRetorno.processar("banco-brasil-1.csv");
    }
}
