package br.edu.ifto.templatemethod;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public abstract class ProcessarBoletos {
    //private LeituraRetorno leituraRetorno;

    protected abstract Boleto processarLinhaArquivo(String[] vetor);

    public final void processar(String caminhoArquivo){
        var lista = new ArrayList<Boleto>();
        try {
            var listaLinhas = Files.readAllLines(Paths.get(caminhoArquivo));
            for (String linha : listaLinhas) {
                var vetor = linha.split(";");
                var boleto = processarLinhaArquivo(vetor);
                lista.add(boleto);
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        lista.forEach(System.out::println);
    }
}
