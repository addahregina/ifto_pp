import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class LeituraRetornoBancoBrasil implements LeituraRetorno {
    @Override
    public List<Boleto> lerArquivo(String nomeArquivo)  {
        System.out.println("Lendo arquivo no BB: "+ nomeArquivo);

        //List<Boleto> listaBoletos = new ArrayList<>();
        var listaBoletos = new ArrayList<Boleto>();

        try{
            var linhasArqs = Files.readAllLines(Paths.get(nomeArquivo));
            for(String linha : linhasArqs){
                //System.out.println(linha);
                var vetor = linha.split(";");  //todas as posições são string, não é possivel usar laço de repetição for
                //id do boleto @descrições no git retornoboleto
                var boleto = new Boleto();
                boleto.setId(Integer.parseInt(vetor[0]));
                boleto.setCodBanco(vetor[1]);
                var fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                boleto.setDataVencimento(LocalDate.parse(vetor[2], fmt));
                boleto.setDataPagamento(LocalDate.parse(vetor[3], fmt).atTime(0,0,0));
                boleto.setCpfCliente(vetor[4]);
                boleto.setValor(Double.parseDouble(vetor[5]));
                boleto.setMulta(Double.parseDouble(vetor[6]));
                boleto.setJuros(Double.parseDouble(vetor[7]));
                listaBoletos.add(boleto);
            }
        } catch (IOException e){
            //exceção não checada, não obriga o método a tratar a exceção.
            throw new RuntimeException(e);
        }

        return listaBoletos;
    }
}
