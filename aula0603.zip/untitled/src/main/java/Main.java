public class Main {
    public static void main(String[] args){

        var processarBoletos = new ProcessarBoletos(new LeituraRetornoBancoBrasil());

        //faz o relacionamento entre as clases
       // processarBoletos.setLeituraRetorno(leituraRetornoBB);

       // processarBoletos.getLeituraRetorno().lerArquivo("banco-brasil-1.csv");


        processarBoletos.processar("banco-brasil-1.csv");
        processarBoletos.setLeituraRetorno(new LeituraRetornoBradesco());
        processarBoletos.processar("bradesco-1.csv");

    }

}
