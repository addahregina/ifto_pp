import java.io.IOException;
import java.io.UncheckedIOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class LeituraRetornoBancoBrasil implements LeituraRetorno {
    @Override
    public List<Boleto> lerArquivo(String caminhoArquivo) {
        try {
            var listaLinhas = Files.readAllLines(Paths.get(caminhoArquivo));
            for (var linha : listaLinhas) {
                var vetor = linha.split(";");
                var boleto = new Boleto();
                //fotocel.
                System.out.println(linha);

            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }

        throw new UnsupportedOperationException("Método não implmentado");

    }
}
