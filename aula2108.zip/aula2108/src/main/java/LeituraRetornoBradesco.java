import java.util.List;

public class LeituraRetornoBradesco implements LeituraRetorno {
    @Override
    public List<Boleto> lerArquivo(String caminhoArquivo) {
        System.out.println("Lendo arquivo no Bradesco:" + caminhoArquivo);
        return null;
    }
}
