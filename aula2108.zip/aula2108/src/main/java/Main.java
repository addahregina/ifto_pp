public class Main {
    public static void main(String[] args){

        var leituraRetorno = new LeituraRetornoBancoBrasil();
        var processador = new ProcessarBoletos(leituraRetorno);

        processador.processar("banco-brasil-1.csv");
    }
}
