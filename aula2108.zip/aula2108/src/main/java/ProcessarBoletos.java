public class ProcessarBoletos {


    public LeituraRetorno getLeituraRetorno() {
        return leituraRetorno;
    }

    public void setLeituraRetorno(LeituraRetorno leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
    }

    private LeituraRetorno leituraRetorno;

    public ProcessarBoletos(LeituraRetorno leituraRetorno) {

        this.leituraRetorno = leituraRetorno;
    }

    public final void processar(String caminhoArquivo) {
        leituraRetorno.lerArquivo(caminhoArquivo);
    }
}
