import java.util.*;
import java.util.stream.IntStream;

public class ConcorrenciaThread extends Thread {

    //SEED = semente
    //se não há variáveis compartilhadas, não precisa de sincronismos
    // private final static Random random = new Random();
    //random é uma variável compartilhada, não é thread safe
    //private final Random random = new Random();
    //private final Random random;
    //private final static List<Character> letras = new ArrayList<>();
    //private final static List<Character> letras = Collections.synchronizedList(new ArrayList<>());
    //private final List<Character> letras = Collections.synchronizedList(new ArrayList<>());
    //private static int totalLetras;

  /* public ConcorrenciaThread(){
       random = new Random(seed);
   }
*/
  //Public static void main(String[] args) throws InterruptedException {
    public static void main(String[] args) {
        var listaFinal = IntStream.range(0,20)
                .parallel()
                .mapToObj(i->run(i))
                .flatMap(lista->lista.stream()) //pega um elemento por vez e joga no final da lista
                .toList();
        System.out.println("size()"+ listaFinal.size());
        System.out.println("Letras: "+listaFinal);
    }

    /*
        var threads = new ConcorrenciaThread[20];

        for(int i=0; i< threads.length; i++){
            //força aguardar a execução das threads antes de terminar a excução.
            threads[i] = new ConcorrenciaThread();
            threads[i].start();
            //new ConcorrenciaThread().start();
        }

        var listafinal = new ArrayList<Character>();

        for (var thread: threads) {
            //exceção checada obriga a lidar com o erro
            thread.join();

            listaFinal.addAll(thread.letras);
           // System.out.println("Total: "+ totalLetras);

        }

        System.out.println("Size(): "+letras.size());
        System.out.println("Letras: "+letras);

        }
*/


    //@Override
    //public void run(int seed) {
    public static List<Character> run(int seed) {

        //quando utilizar threads usar final para evitar reutilização de variáveis.
       final var random = new Random(seed);
       final List<Character> letras = new ArrayList<>();
        //super.run();

        for (int i = 0; i < 1000; i++) {
            int n = Math.abs(random.nextInt(122)); //random gera um inteiro aleatório, positivos ou negativos, abs retorna o valor absoluto sem sinal
            if(n>=65) {

                letras.add((char) n);
                // addLetra((char) n);
                //totalLetras++;
                //incrementa();
            }
        }

        return letras;
    }

    /*
    synchronized static private void incrementa(){
        totalLetras++;
    }
    //synchronized - controla a execução do codigo; permite uma excecução por vez
    //syncronized list faz o encapsulamento automaticamente.

    //synchronized private static void addLetra(char n){
    private static void addLetra(char n){
        letras.add(n);
        totalLetras++;
    }
     */
}
