import com.manoelcampos.retornoboleto.LeituraRetorno;
import com.manoelcampos.retornoboleto.LeituraRetornoBradesco;
import com.manoelcampos.retornoboleto.LeituraRetornoBancoBrasil;
import com.manoelcampos.retornoboleto.ProcessarBoletos;

/**
 * Classe para ver o funcionamento da leitura de boletos.
 *
 * @author Manoel Campos da Silva Filho
 */
public class Principal {
    public static void main(String[] args) {
        var leituraRetorno = new LeituraRetornoBancoBrasil();
        configurar(leituraRetorno);

        var processador = new ProcessarBoletos(leituraRetorno);
        processador.processar("banco-brasil-1.csv");

        var leituraBradesco = new LeituraRetornoBradesco();
        processador.setLeituraRetorno(new LeituraRetornoBradesco());
        processador.processar("bradesco-1.csv");
    }

    private static void configurar(LeituraRetorno leituraRetorno) {

    }
}
