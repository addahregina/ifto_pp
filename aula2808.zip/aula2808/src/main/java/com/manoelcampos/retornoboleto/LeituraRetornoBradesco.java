package com.manoelcampos.retornoboleto;

import com.manoelcampos.retornoboleto.LeituraRetorno;

public class LeituraRetornoBradesco implements LeituraRetorno {
    @Override
    public List<Boleto> lerArquivo(String caminhoArquivo){
        throw new UnsupportedOperationException("Método ainda não implementado");
    }
}
