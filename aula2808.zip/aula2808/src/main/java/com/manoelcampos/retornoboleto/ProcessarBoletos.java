package com.manoelcampos.retornoboleto;

/**
 * Processa arquivos de retorno de boletos bancários utilizando a implementação de
 * alguma estratégia ({@link LeituraRetorno}).
 * Esta é uma classe que chamamos de Estrategista,
 * por poder utilizar diferentes estratégias de acordo com as necessidades,
 * podendo mudar a estratégia a ser utilizada até em tempo de execução.
 *
 * @author Manoel Campos da Silva Filho
 */
public class ProcessarBoletos {
    private LeituraRetorno leituraRetorno;

    public ProcessarBoletos(LeituraRetorno leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
    }


    public final void processar(String caminhoArquivo){
        var boletos = leituraRetorno.lerArquivo(caminhoArquivo);
        //implementar loop para imprimir boleto por linha
        boletos.forEach(System.out::println); //dois pontos passa a função por parâmetro para outra função
        //double total = boletos.stream().mapToDouble(Boleto::getValor).sum();

    }

    public void setLeituraRetorno(LeituraRetorno leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
    }
}
