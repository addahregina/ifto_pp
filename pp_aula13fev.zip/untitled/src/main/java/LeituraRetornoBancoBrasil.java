import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class LeituraRetornoBancoBrasil implements LeituraRetorno {
    @Override
    public List<Boleto> lerArquivo(String nomeArquivo)  {
        System.out.println("Lendo arquivo no BB: "+ nomeArquivo);

        //List<Boleto> listaBoletos = new ArrayList<>();
        var listaBoletos = new ArrayList<Boleto>();

        try{
            var linhasArqs = Files.readAllLines(Paths.get(nomeArquivo));
            for(String linha : linhasArqs){
                System.out.println(linha);
            }
        } catch (IOException e){
            //exceção não checada, não obriga o método a tratar a exceção.
            throw new RuntimeException(e);
        }

        return listaBoletos;
    }
}
