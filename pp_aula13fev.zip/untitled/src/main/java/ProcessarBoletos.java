public class ProcessarBoletos {

    private LeituraRetorno leituraRetorno;

    public ProcessarBoletos(LeituraRetorno leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
    }

    /*
    //é substituido pelo método processarBoletos
        public LeituraRetorno getLeituraRetorno() {
            return leituraRetorno;
        }
    */

    public void setLeituraRetorno(LeituraRetorno leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
    }

    void processar(String nomeArquivo) {
        //recebe o nome do arquivo e repassa para estratégia
        leituraRetorno.lerArquivo(nomeArquivo);
    }
}

